chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (message.type === 'SET_TOKEN') {
    chrome.storage.local.set({ wv_token: message.token }, () => {
      sendResponse({ ok: true });
    });
    return true;
  }
});
